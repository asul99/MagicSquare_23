"""MagicSquare application package root."""
